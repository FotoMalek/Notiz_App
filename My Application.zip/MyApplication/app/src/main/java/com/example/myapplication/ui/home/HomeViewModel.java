package com.example.myapplication.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class HomeViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    private final MutableLiveData<String> mText1;

    public HomeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Hier ist die Startseite");
        mText1 = new MutableLiveData<>();
        mText1.setValue("Schönen Tag wünschen wir dir");
    }

    public LiveData<String> getText() {
        return mText;
    }

    public LiveData<String> getText2(){return mText1;}
}