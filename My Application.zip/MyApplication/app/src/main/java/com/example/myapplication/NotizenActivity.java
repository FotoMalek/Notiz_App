package com.example.myapplication;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

    public class NotizenActivity extends AppCompatActivity {

        private EditText editTextNotiz;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.fragment_notizen);

            editTextNotiz = findViewById(R.id.editTextNotiz);
            Button buttonSpeichern = findViewById(R.id.buttomSpeichern);

            buttonSpeichern.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    speichernNotiz();
                }
            });
        }

        private void speichernNotiz() {
            String notizText = editTextNotiz.getText().toString();

            // Hier könntest du den Notiztext in einer Datenbank, Datei oder anderen Speicherort speichern.

            Toast.makeText(this, "Notiz gespeichert: " + notizText, Toast.LENGTH_SHORT).show();
            finish();
        }
    }