package com.example.myapplication.ui.notizen;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.myapplication.databinding.FragmentNotizenBinding;

public class NotizenFragment extends Fragment {

    private FragmentNotizenBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        NotizenViewModel notizenViewModel =
                new ViewModelProvider(this).get(NotizenViewModel.class);

        binding = FragmentNotizenBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textNotizen;
        notizenViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}