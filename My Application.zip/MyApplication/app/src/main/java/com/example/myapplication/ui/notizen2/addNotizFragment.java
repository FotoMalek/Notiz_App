package com.example.myapplication.ui.notizen2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.myapplication.R;

public class addNotizFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_add_notiz, container, false);
        // Hier kannst du die Logik für das Speichern der Notiz implementieren
        Button buttonZurueck = rootView.findViewById(R.id.buttonZurueck);
        buttonZurueck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Speichern der Notiz implementieren
                NavController navController = Navigation.findNavController(requireView());
                navController.navigate(R.id.action_navigation_add_notiz_to_navigation_notizen2);
            }
        });


        return rootView;
    }
}
