package com.example.myapplication.ui.notizen2;

public class Notiz {
    private String titel;
    private String inhalt;

    public Notiz(String titel, String inhalt) {
        this.titel = titel;
        this.inhalt = inhalt;
    }

    public String getTitel() {
        return titel;
    }

    public String getInhalt() {
        return inhalt;
    }
}
