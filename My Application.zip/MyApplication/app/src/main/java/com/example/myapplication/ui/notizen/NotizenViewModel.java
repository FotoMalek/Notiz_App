package com.example.myapplication.ui.notizen;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class NotizenViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public NotizenViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Übersicht aller Notizen");
    }

    public LiveData<String> getText() {
        return mText;
    }
}