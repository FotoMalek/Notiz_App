package com.example.myapplication.ui.dashboard;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class DashboardViewModel extends ViewModel {

    private final MutableLiveData<String> mText;
    private final MutableLiveData<String> mText1;

    public DashboardViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Gerade Bist du auf der Kalenderseite");
        mText1 = new MutableLiveData<>();
        mText1.setValue("Wir erbeiten gerade daran noch");
    }

    public LiveData<String> getText(){return mText;}
    public LiveData<String> getText2(){return mText1;}
}