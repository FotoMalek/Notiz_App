package com.example.myapplication.ui.notizen2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import com.example.myapplication.R;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;


public class NotizAdapter extends RecyclerView.Adapter<NotizAdapter.NotizViewHolder> {
    private List<Notiz> notizenListe;

    public NotizAdapter(List<Notiz> notizenListe) {
        this.notizenListe = notizenListe;
    }

    @NonNull
    @Override
    public NotizViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_notiz, parent, false);
        return new NotizViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NotizViewHolder holder, int position) {
        Notiz notiz = notizenListe.get(position);
        holder.titelTextView.setText(notiz.getTitel());
    }

    @Override
    public int getItemCount() {
        return notizenListe.size();
    }

    public static class NotizViewHolder extends RecyclerView.ViewHolder {
        public TextView titelTextView;

        public NotizViewHolder(View itemView) {
            super(itemView);
            titelTextView = itemView.findViewById(R.id.text_notiz_titel);
        }
    }
}
